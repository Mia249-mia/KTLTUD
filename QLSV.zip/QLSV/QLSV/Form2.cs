﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV
{
    public partial class Form2 : Form
    {
        // truy cap vao Class BLL ( tao ra 1 doi tuong)
        StudentBLL svbll;
        public Form2()
        {
            InitializeComponent();
            // khoi tao bll trong ham tao cua form 2
            svbll = new StudentBLL();
        }
        //viet phuong thuc
        public void ShowAllStudent()
        {
            //khai bao 1 doi tuong tuong ung datatble
            DataTable dt = svbll.getAllStudent();
            // chuyen vao data gridview
            dataGridView1.DataSource = dt; 
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentDataSet1.Student' table. You can move, or remove it, as needed.
            this.studentTableAdapter1.Fill(this.studentDataSet1.Student);
            ShowAllStudent();
        }
        public bool CheckData()
        {            
                if (string.IsNullOrEmpty(TxtStudentID.Text))
                {
                    MessageBox.Show("Bạn chưa nhập mã sinh viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    TxtStudentID.Focus();
                    return false;
                }
                if (string.IsNullOrEmpty(txtName.Text))
                {
                    MessageBox.Show("Bạn chưa nhập tên sinh viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtName.Focus();
                    return false;
                }
                if (string.IsNullOrEmpty(txtAddress.Text))
                {
                    MessageBox.Show("Bạn chưa nhập địa chỉ.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtAddress.Focus();
                    return false;
                }
                if (string.IsNullOrEmpty(txtClass.Text))
                {
                    MessageBox.Show("Bạn chưa nhập lớp học.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtClass.Focus();
                    return false;
                }
                if (string.IsNullOrEmpty(txtGrades.Text))
                {
                    MessageBox.Show("Bạn chưa nhập Điểm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtGrades.Focus();
                    return false;
                }
                return true;
        }

        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            if(CheckData())
            {
                //khoi tao doi tuong cua lop Student da lam 
                Student sv = new Student();
                sv.StudentID = TxtStudentID.Text;
                sv.Name = txtName.Text;
                sv.Address = txtAddress.Text;
                sv.Class = txtClass.Text;
                sv.Grades = Double.Parse(txtGrades.Text);
                //neu nhu check dung roi thi goi ham insert sinh vien ra o lop bll
                if(svbll.Insert(sv))
                    ShowAllStudent();
                else
                    MessageBox.Show("Đã có lỗi xảy ra,xin thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditStudent_Click(object sender, EventArgs e)
        {
            if (CheckData())
            {
                Student sv = new Student();
                sv.id = id;
                sv.StudentID = TxtStudentID.Text;
                sv.Name = txtName.Text;
                sv.Address = txtAddress.Text;
                sv.Class = txtClass.Text;
                sv.Grades = Double.Parse(txtGrades.Text);
                if (svbll.Update(sv))
                    ShowAllStudent();
                else
                    MessageBox.Show("Đã có lỗi xảy ra,xin thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        // khai bao bien id(bien toan cuc )sau khi nhan vao thi biet bien id cua no la gi
        int id;
        
        private void btnDeleteStudent_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("bạn có muốn xóa hay ko?","cảnh báo",MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) 
            {
                Student sv = new Student();
                sv.id = id;
                if (svbll.Delete(sv))
                    ShowAllStudent();
                else
                    MessageBox.Show("Đã có lỗi xảy ra,xin thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string value = txtsearch.Text;
            if(!string.IsNullOrEmpty(value)) 
            {
                DataTable dt = svbll.find(value);
                dataGridView1.DataSource = dt;
            }
            else
            {
                ShowAllStudent() ;
            }
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            if (index >= 0)
            {
                id = Int32.Parse(dataGridView1.Rows[index].Cells["idDataGridViewTextBoxColumn"].Value.ToString());
                // lam ham thay doi trong cells co 2 cach 1 la dat ten cot hai la lam theo ten cua name cuar cot
                TxtStudentID.Text = dataGridView1.Rows[index].Cells["StudentID"].Value.ToString();
                //C2 TxtStudentID.Text = dataGridView1.Rows[index].Cells["1"].Value.ToString()
                txtName.Text = dataGridView1.Rows[index].Cells["Name"].Value.ToString();
                txtAddress.Text = dataGridView1.Rows[index].Cells["Address"].Value.ToString();
                txtClass.Text = dataGridView1.Rows[index].Cells["Class"].Value.ToString();
                txtGrades.Text = dataGridView1.Rows[index].Cells["Grades"].Value.ToString();
            }
        }
    }
}
