﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV
{
    internal class Dataconnection
    {
        String conStr;
        public Dataconnection() 
        {
            conStr = "Data Source=QUANGANH;Initial Catalog=Student;Integrated Security=True;TrustServerCertificate=True";
        }
        public SqlConnection GetConnect() 
        {
            return new SqlConnection(conStr);
        }
        
    }
}
