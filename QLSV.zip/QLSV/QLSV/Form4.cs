﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace QLSV
{
    public partial class Form4 : Form
    {
        StudentBLL usbll;
        public Form4()
        {
            InitializeComponent();
            usbll = new StudentBLL();
        }
        // check mat khau va ten tai khoan
        public bool Checkdata()
        {


            if (string.IsNullOrEmpty(TxtUsers.Text))
            {
                MessageBox.Show("Bạn chưa nhập user.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TxtUsers.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Bạn chưa nhập mã sinh viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Focus();
                return false;
            }

            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                MessageBox.Show("Bạn chưa nhập mã sinh viên.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
                return false;
            }
            return true;
        }
        private void btndangky_Click(object sender, EventArgs e)
        {
            if (Checkdata())
            {
                Users us = new Users();
                us.UserName = TxtUsers.Text;
                us.Password = txtPassword.Text;
                us.Email = txtEmail.Text;
                if (usbll.dangky(us))
                {
                    if (MessageBox.Show("Đăng ký thành công! Bạn có muốn vào luôn không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        Form2 newForm = new Form2();
                        newForm.Show();
                    }
                }
                else
                    MessageBox.Show("Đã có lỗi xảy ra,xin thử lại sau", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }
    }
}
