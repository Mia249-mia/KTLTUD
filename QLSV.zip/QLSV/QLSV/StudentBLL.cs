﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV
{
    class StudentBLL
    {
        // khoi tao lop Data Access Layer (DAL)
        StudentDal dal;
        // tao 1 ham tao sinh vien bll
        public StudentBLL()
        {
            // khoi tao doi tuong DAl]\
            dal = new StudentDal();
        }
        public DataTable getAllStudent()
        {
            //goi lai phuong thuc dal
            return dal.getAllStudent();
        }
        public bool Insert(Student sv)
        {
            return dal.Insert(sv);
        }
        public bool Update(Student sv)
        {
            return dal.Update(sv);
        }
        public bool Delete(Student sv)
        {
            return dal.Delete(sv);
        }
        public DataTable find(string sv)
        {
            return dal.find(sv);
        }
        public bool dangky(Users us)
        {
            return dal.dangky(us);
        }
    }
}
