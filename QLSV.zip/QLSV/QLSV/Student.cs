﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV
{
    class Student
    {
        public int id { get; set; }
        public string StudentID { get; set; }
        public string Name { get; set; }
        public string Class { get; set; }
        public double Grades { get; set; }
        public string Address { get; set; }
    }
}
