﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLSV
{
    internal class StudentDal
    {
        Dataconnection dc;
        SqlDataAdapter da;
        SqlCommand cmd;
        public StudentDal()
        {
            dc = new Dataconnection();
        }
        public DataTable getAllStudent()
        {
            //B1: tao cau lenh sql lay toan bo sinh vien 
            string sql = "SELECT * FROM Student";
            //B2: tao mot ket noi voi den SQL
            SqlConnection con = dc.GetConnect();
            //B3:khoi tao doi tuong cua lop SqldataAdapter
            da = new SqlDataAdapter(sql, con);
            //B4: Mo ket noi 
            con.Open();
            //B5: dua DataAdapter vao datatable
            DataTable dt = new DataTable();
            da.Fill(dt);
            //B6: dong cong
            con.Close();
            return dt;
        }
        //làm như ở bảng getAllStudent

        public bool Insert(Student sv) 
        {
            string sql = "INSERT INTO Student(StudentID, Name, Address, Class, Grades) VALUES(@StudentID, @Name, @Address, @Class, @Grades)";
            SqlConnection con = dc.GetConnect();
            // mo ket noi nay de bi gian doan nen mo ham try de bat loi
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
               // cmd.Parameters("các hàm sql, kiểu dữ liệu đến đâu = sv đến trường nào" 
                cmd.Parameters.Add("@StudentID", SqlDbType.NVarChar).Value =sv.StudentID;
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = sv.Name;
                cmd.Parameters.Add("@Address", SqlDbType.NVarChar).Value = sv.Address;
                cmd.Parameters.Add("@Class", SqlDbType.NVarChar).Value = sv.Class;
                cmd.Parameters.Add("@Grades", SqlDbType.Float).Value = sv.Grades;
                // phai co cau lenh ExecuteNonQuery moi thuc thi cau lenh
                cmd.ExecuteNonQuery();
                //mo thi phai dong truong lai
                con.Close();
            }
            catch (Exception e) 
            {
                return false;
            }
            return true;
        }
        // làm như Insert nhưng thay hàm sql
        public bool Update(Student sv)
        {
            string sql = "UPDATE Student SET StudentID = @StudentID, Name = @Name, Address = @Address, Class = @Class, Grades =@Grades WHERE id =@id";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = sv.id;
                cmd.Parameters.Add("@StudentID", SqlDbType.NVarChar).Value = sv.StudentID;
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = sv.Name;
                cmd.Parameters.Add("@Address", SqlDbType.NVarChar).Value = sv.Address;
                cmd.Parameters.Add("@Class", SqlDbType.NVarChar).Value = sv.Class;
                cmd.Parameters.Add("@Grades", SqlDbType.Float).Value = sv.Grades;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public bool Delete(Student sv) 
        {
            string sql = "DELETE Student WHERE id =@id";
            SqlConnection con = dc.GetConnect();
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = sv.id;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }
        public DataTable find (string sv) 
        {
            // like% (cau lenh tim kiem )
            string sql = " SELECT * FROM Student WHERE Name like'%" + sv + "%' OR Class like '%" + sv + "%'";
            SqlConnection con = dc.GetConnect();
            //B3:khoi tao doi tuong cua lop SqldataAdapter
            da = new SqlDataAdapter(sql, con);
            //B4: Mo ket noi 
            con.Open();
            //B5: dua DataAdapter vao datatable
            DataTable dt = new DataTable();
            da.Fill(dt);
            //B6: dong cong
            con.Close();
            return dt;
        }
        public bool dangky(Users us)
        {
            string sql = "INSERT INTO Student(UserName, Password, Email) VALUES(@UserName, @Password,@Email)";
            SqlConnection con = dc.GetConnect();
            // mo ket noi nay de bi gian doan nen mo ham try de bat loi
            try
            {
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = us.id;
                cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = us.UserName;
                cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = us.Password;
                cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = us.Email;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception e)
            {
                return false;
            }
            return true;

        }
    }
}
